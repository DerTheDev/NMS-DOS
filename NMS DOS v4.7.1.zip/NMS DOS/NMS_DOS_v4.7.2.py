#startup
from nmslib import debug
debug('','Preparing NMS DOS')
new = 1
url = "https://www.google.com"
debug('','Importing modules... 1/11')
import sys
debug('','Importing modules... 2/11')
import os
debug('','Importing modules... 3/11')
import webbrowser as internet
debug('','Importing modules... 4/11')
import time
debug('','Importing modules... 5/11')
import ctypes
debug('','Importing modules... 6/11')
import warnings
debug('','Importing modules... 7/11')
import getpass
debug('','Importing modules... 8/11')
import winsound
debug('','Importing modules... 9/11')
import cmd
debug('','Importing modules... 10/11')
import ctypes
debug('','Importing modules... 11/11')
import tkMessageBox as tkmb
debug('','Finished importing modules.')
debug('','Getting user data... 1/2')
user = getpass.getuser()
debug('','Getting user data... 2/2')
path = os.getcwd()
debug('','Finished getting user data')
debug('','Initializing 1/1')
cmd.Cmd.intro = 'NMS DOS [Version 4.7.2]'
time.sleep(1.5)
debug('','Finished initializing.')
debug('','Ready!')
print ''
print ''
time.sleep(2)
if os.name == 'nt': #Clears screen
    os.system('cls')
else:
    os.system('clear')

#Session start
debug('','Beginning NMS DOS')
print ''
print ''
print 'Confirming EULA (End User Liscense Agreement)'
eula = ctypes.windll.user32.MessageBoxA(0, "NMS DOS End User Liscense Agreement:\rDO NOT use any material from NMS DOS unless you contact the TGT Team at thetgtteam@gmail.com or at tgt-gaming.weebly.com and give credit.", "NMS DOS End User Liscense Agreement", 0x01) #EULA check
print "EULA is " + str(eula)
if not eula == 1:
    sys.exit(13)
    exit()
if 1 == 1 == 1:
    debug('','No errors detected')
else:
    debug('WARNING','An unknown error has occured, continuing with bootup may cause damage to NMS DOS and your computer.')
    bootup_cont = ctypes.windll.user32.MessageBoxA(0, 'An unknown error occured during bootup, continuing may cause damage to NMS DOS and your computer. \rDo you want to continue anyways? Click YES to continue, NO to retry, or CANCEL to exit.', 'NMS DOS', 0x30 | 0x03)
    print bootup_cont
    if bootup_cont == 6:
        ctypes.windll.user32.MessageBoxA(0, 'Continuing bootup anyways.', 'NMS DOS', 0x30)
    elif bootup_cont == 7:
        retry = ctypes.windll.user32.MessageBoxA(0, 'Do you want to restart NMS DOS?', 'NMS DOS', 0x30 | 0x04)
        print retry
        if retry == 6:
            debug('', 'Attempting to restart NMS DOS, please wait.')
            r = os.system('start NMS_DOS_v4.7.2.py')
            if r == 0:
                sys.exit
                exit()
            else:
                ctypes.windll.user32.MessageBoxA(0, 'Could not auto-restart NMS DOS, please restart manually. \rClick OK to exit.', 'NMS DOS', 0x10)
                raise RuntimeError
                sys.exit
                exit()
        else:
            ctypes.windll.user32.MessageBoxA(0, 'Click OK to exit NMS DOS.', 'NMS DOS', 0x40)
            sys.exit
            exit()
    else:
        ctypes.windll.user32.MessageBoxA(0, 'Click OK to exit NMS DOS.', 'NMS DOS', 0x40)
        sys.exit
        exit()

print ""
print ""
print ""
print ""
print ""
print cmd.Cmd.intro #Title
print "Welcome, " + str(user) + "."
print "OS Platform: " + str(sys.platform)
print "OS Name: " + str(os.name)
print("Type help for a list of commands.")
while True: # command loop
    print ''
    answer = raw_input("Enter command: ").lower()
    if answer == "help":
        print("---Showing all valid commands---")
        print("  ")
        print("HELP - Shows all valid commands.")
        print("VER - Shows NMS DOS version.")
        print("EXIT - Exits NMS DOS.")
        print("UPDATES - Shows what's new in this Edition of NMS DOS!")
        print("ERROR - Shows a custom error message with the given inputs.")
        print("WEBPAGE - Opens a webpage to the requested address.")
        print "ECHO - returns specified text."
        print 'SHUTDOWN - Shuts down your computer. (Windows only, May require administrator permissions.)'
        print ' - /a (SHUTDOWN /A) Aborts the shutdown if one is active.'
        print 'RESTART - Restarts your computer. (Windows only, May require administrator permissions.)'
        print 'CWD - Checks (returns) the directory of NMS DOS.'
        print 'LS - Lists the NMS DOS directory.'
        print 'CLEAR - Clears the NMS DOS Terminal.'
        print 'BEEP() - Plays a default computer beep noise. (Windows only)'
        print 'DRIVERQUERY - Displays current device driver status and properties. (Windows only, May require administrator permissions.)'
        print 'CMD - Exits NMS DOS and starts the Windows Command-Line. (Windows only, May require administrator permissions.)'
        print 'DEBUG - Returns text specified by the user in debug format.'
    elif answer == "ver":
        print "NMS DOS Version: Release 4.7.2"
        print "By the TGT Team"
    elif answer == "exit":
        choose_shutdown = tkmb.askyesno("NMS DOS", "Are you sure you want to exit NMS DOS?")
        if choose_shutdown == True:
            sys.exit()
            exit()
        else:
           debug('','Could not exit NMS DOS; user aborted exit.')
    elif answer == "webpage":
        url = raw_input("What URL do you want to go to? ")
        confirm_webpage = tkmb.askyesno("NMS DOS", "Are you sure you want to go to " + url + "?")
        if confirm_webpage == True:
            internet.open(url, new=new)
        else:
            tkmb.showerror("NMS DOS", "Failed to go to " + url)
            winsound.PlaySound("SystemHand", winsound.SND_ALIAS)
            print "Failed to go to " + url
    elif answer == "updates":
        print "What's new in NMS DOS 4.7.2"
        print ' - Starting to replace \'tkMessageBox\' with \'ctypes\''
    elif answer == "error":
        err_title = raw_input("What should the error's title be? ")
        err_text = raw_input("What should the error text be? ")
        tkmb.showinfo(err_title, err_text)
    elif answer == 'echo':
        echo = raw_input('echo ')
        print echo
    elif answer == 'shutdown':
        tkmb.showwarning("NMS DOS", "Your computer will shutdown in 60 seconds. \rTo abort this shutdown, type SHUTDOWN /A.")
        shutdown = os.system("shutdown -s")
        if shutdown == 1190:
            tkmb.showerror('NMS DOS','A system shutdown has already been scheduled.(1190)')
        else:
            tkmb.showwarning("NMS DOS", "Your computer will shutdown in 60 seconds. \rTo abort this shutdown, type SHUTDOWN /A.")
    elif answer == 'restart':
        restart = os.system("shutdown -r")
        if restart == 1190:
            tkmb.showerror('NMS DOS','A system shutdown has already been scheduled.\r(1190)')
        else:
            tkmb.showwarning("NMS DOS", "Your computer will restart in 60 seconds. \rTo abort this restart, type SHUTDOWN /A.")
    elif answer == 'shutdown /a':
        shutdown_a = os.system("shutdown -a")
        if shutdown_a == 1116:
            tkmb.showerror("NMS DOS", "Unable to abort the system shutdown because no shutdown was in progress. \r(1116)")
        else:
            tkmb.showinfo("NMS DOS", "Shutdown aborted.")
    elif answer == 'cwd':
        print 'Checking Working Directory'
        print path
    elif answer == 'ls':
        print os.listdir(path)
    elif answer == 'clear':
        if os.name == 'nt':
            os.system('cls')
        else:
            os.system('clear')
        print cmd.Cmd.intro #Title
        print "Welcome, " + str(user) + "."
        print "OS Platform: " + str(sys.platform)
        print "OS Name: " + str(os.name)
        print("Type help for a list of commands.")
    elif answer == 'beep':
        print 'Invalid syntax. Usage: BEEP()'
        winsound.PlaySound("SystemHand", winsound.SND_ALIAS)
    elif answer == 'beep()':
        winsound.Beep(1000, 750)
    elif answer == 'driverquery':
        print '========== BEGIN DRIVER QUERY =========='
        print ''
        os.system('driverquery')
        print ''
        print '========== END DRIVER QUERY =========='
    elif answer == 'cmd':
        print '========== ENDING NMS DOS SESSION =========='
        print ''
        debug('','Starting command-line.')
        debug('','Type \'EXIT\' to retrun to NMS DOS.')
        print ''
        os.system('cmd')
        print ''
        debug('','Returning to NMS DOS')
        print ''
    elif answer == 'debug':
        debug_input = raw_input('Enter message: ')
        debug(user,debug_input)
    else:
        if not answer == '':
            print "'" + answer + "' is not a valid command. Type HELP for help."
            winsound.PlaySound("SystemHand", winsound.SND_ALIAS)
