''' NMSlib - By the TGT Team
    This work is liscensed under a Creative Commons Attribution NonCommercial 4.0 liscense.
    Information on the liscense is available at https://creativecommons.org/licenses/by-nc/4.0/
    An external program for NMS DOS. '''

if __name__ == '__main__':
    import ctypes
    ctypes.windll.user32.MessageBoxA(0, 'This is an external program for NMS DOS.\rIt is not designed for use as an external program.', 'nmslib', 0x0)


def msg(title, message, arguments=0x0):
    import ctypes
    ctypes.windll.user32.MessageBoxA(0, message, title, arguments)

def progressbar(progress, line1=None):
    import os
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')
    progress = round(progress)
    print line1
    print ''
    if progress <= 10 and progress > -1:
        print '[#         ]' + str(progress) + '%'
    elif progress <= 24:
        print '[##        ]' + str(progress) + '%'
    elif progress <= 34:
        print '[###       ]' + str(progress) + '%'
    elif progress <= 44:
        print '[####      ]' + str(progress) + '%'
    elif progress <= 54:
        print '[#####     ]' + str(progress) + '%'
    elif progress <= 64:
        print '[######    ]' + str(progress) + '%'
    elif progress <= 74:
        print '[#######   ]' + str(progress) + '%'
    elif progress <= 84:
        print '[########  ]' + str(progress) + '%'
    elif progress <= 99:
        print '[######### ]' + str(progress) + '%'
    elif progress == 100:
        print '[##########]' + str(progress) + '%'
    else:
        print 'Warning:'
        print 'File ' + str(__name__)
        print 'ProgressError: "' + str(progress) + '" is not a vaild number, it must be between -1 and 101.'

def package(name):
    __name__ = str(name)

def debug(caller, message):
    if caller == '':
        caller = '[@]'
    if message == '':
        message = 'null'
    print '[DEBUG]: ' + str(caller) + ': ' + str(message)

def clear():
    import os
    if os.name == 'nt':
        os.system('cls')
    else:
        os.system('clear')
